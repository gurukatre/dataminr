import Panel from './components/panel/Panel';

function App() {
  return (
    <div className="App">
      <Panel />
    </div>
  );
}

export default App;
